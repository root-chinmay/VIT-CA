# VibeCraft — The AI-Era Coding Assessment Platform
> **Code Apex 2026** | **Track-2 PS1: The AI-Era Coding Assessment**  
> Developed by Team **`APK AutoPsy`** | Team Leader: **Ridhisha Vinod Agawane**  
> Powered by **Verzii** &bull; **AISF** &bull; **VCA**

---

## 🎯 Executive Summary & The Problem Statement

In the modern generative AI era, developers no longer write code in an isolated white-room without tools. Today, engineers work collaboratively with AI through:
$$\text{Planning} \longrightarrow \text{Prompting} \longrightarrow \text{Coding} \longrightarrow \text{Testing} \longrightarrow \text{Debugging}$$

### The Critical Gap (Slide 2):
* **Recruiters** cannot distinguish between genuine software engineers and blind "Vibe Coders" who copy-paste hallucinations from ChatGPT without understanding.
* **Traditional Assessments** only evaluate the final 20 lines of code (`Input -> Output`), failing to measure critical thinking, verification discipline, or adaptability.
* **The Paradigm Shift**:
  * ❌ *Obsolete 2020 Mindset*: "Can you write code without AI?"
  * ✅ *VibeCraft 2026 Mindset*: **"Can you collaborate with AI, catch and fix bugs, and make the solution your own?"**

---

## ⚡ The 6 Core Innovations (Slide 5)

1. **Fake Hints (Trojan Injector)**:
   The AI Coach periodically injects subtly flawed or suboptimal hints. Candidates who catch and refute them earn massive verification points; candidates who follow them blindly lose points.
2. **Holistic Skill Leaderboard**:
   Ranked by comprehensive engineering maturity rather than brute-force speed. Features cohort filtering (Backend, Frontend, AI Systems) and badges (*Debugging Pro*, *Test Master*, *Adversarial Hawk*).
3. **Sudden Change in Requirements (Spec Shock)**:
   Mid-task curveballs that reflect real-world sprint shifts (e.g., multi-tenant isolation, streaming payloads). Tests clean refactoring under pressure.
4. **Verified Skill Passport**:
   Tamper-proof, cryptographically signed credentials (`SHA-256`) that record past attempts, AI fluency, and verified evidence logs—reusable across hiring companies.
5. **Live 5-Axis Skill Radar**:
   Real-time telemetry tracking: **Coding**, **Testing**, **Debugging**, **Verification**, and **AI Collaboration**.
6. **Integrity Guard**:
   Monitors paste velocity, sudden monolithic clipboard dumps, and tab switching without invasive screen-locking spyware.

---

## 🏗️ System Architecture & Tech Stack (Slide 3 & Slide 6)

* **Frontend**: Next.js, React, Monaco Editor, Canvas/SVG Radar Engine
* **Backend**: Python, FastAPI, Microservices Mesh, High-Throughput Event Ingest
* **Data Stores**:
  * **MongoDB**: Stores session logs, prompt histories, and code diff snapshots
  * **PostgreSQL**: Stores verified skills, passports, user profiles, and test rubrics
* **Sandboxing & AI**:
  * **Judge0 Sandbox**: Isolated Docker containers for multi-language execution
  * **LLM API Gateway**: Stateful AI coaching with custom trojan hint policies
* **Async Workers & Scalability**:
  * Load balancer spreading 1,000s of candidate sessions across horizontal app instances
  * Redis/BullMQ job queues decoupling background AI evaluation and report building

---

---

## 🔐 Separate Role Portals & Role-Based Access Control (RBAC)

VibeCraft provides dedicated authentication portals and granular access controls tailored to each role:

| Feature / Control | 👨‍💻 Candidate Role (`candidate-login.html`) | 💼 Recruiter Role (`recruiter-login.html`) |
| :--- | :---: | :---: |
| **Interactive IDE & Test Runner** | ✅ Full Access (Python 3.12 Sandboxed) | ✅ Read & Simulator Auditing |
| **AI Pair-Programming Coach** | ✅ Real-time Dialogue & Assistance | ✅ Review Full Prompt & Response Logs |
| **Live 5-Axis Radar Telemetry** | ✅ Live Real-Time Dynamic Feedback | ✅ Historical & Multi-Candidate Benchmark |
| **Verified Skill Passport** | ✅ Downloadable & Shareable Credential | ✅ Verification & ATS Ingest |
| **Adversarial Hint Injections** | 🔒 **Restricted from Candidate** (Injected automatically by AI Proctor or live recruiter) | ⚡ **Manual Injection Authority** (Live Evaluator Test Console with instant dispatch buttons) |
| **Forensic Keystroke & Diff Logs**| 🔒 Hidden to Preserve Exam Integrity | ✅ Unlocked Timestamped Evidence Audit |
| **Integrity Telemetry (Tab Switches)**| 🔒 Internal Audit Engine | ✅ Full Forensic Anomaly Timeline |
| **Hiring Decision Actions** | 🔒 Restricted | ✅ "Advance to Final Round" & Signed PDF Export |

### ⚡ Quick Demo Credentials (1-Click Auto-Fill Available)
* **Candidate Portal** (`/candidate-login.html`):
  * **Email**: `ridhisha.agawane@apk-autopsy.ai`
  * **Token**: `VIBE-2026-APEX-8904`
* **Recruiter Portal** (`/recruiter-login.html`):
  * **Work Email**: `marcus.vance@verziicorp.com`
  * **Partner Key**: `VERZII-ENTERPRISE-KEY-9942`

---

## 🚀 How to Run Locally

1. Start a local HTTP server:
   ```bash
   python -m http.server 3000
   ```
2. Open your web browser and navigate to:
   * **Main Assessment Platform**: `http://localhost:3000`
   * **Candidate Login Portal**: `http://localhost:3000/candidate-login.html`
   * **Recruiter Login Portal**: `http://localhost:3000/recruiter-login.html`
3. Explore the interactive modules:
   * **Live Candidate Sandbox**: Run test suites in the Judge0 terminal, trigger a Fake Hint, catch the flaw, and observe the Live Radar chart adapt.
   * **Recruiter Dossier**: Click timeline timestamps to review prompt logs, test diffs, and verification metrics.
   * **Verified Skill Passport**: Click "Verify Skill Passport" to inspect the 3D holographic card and test ledger lookup (`8904`).
   * **Leaderboard & Benchmarks**: Filter by cohort and inspect the 7-dimension evaluation gap chart.

---

## 👥 Team Credits
* **Team**: `APK AutoPsy`
* **Team Leader**: Ridhisha Vinod Agawane
* **Event**: Code Apex (Powered by verzii)
* **Track**: Track-2 PS1: The AI-Era Coding Assessment
