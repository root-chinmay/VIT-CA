/**
 * VibeCraft — The AI-Era Coding Assessment Platform
 * Client-Side Application Logic & Interactive Assessment Engine
 * Team: APK AutoPsy | Lead: Ridhisha Vinod Agawane | Code Apex Track-2 PS1
 */

(function () {
  'use strict';

  // State Management
  const state = {
    viewMode: 'recruiter', // 'recruiter' | 'candidate'
    sfxEnabled: true,
    radarScores: {
      coding: 80,
      testing: 72,
      debugging: 85,
      verification: 90,
      aiCollab: 78
    },
    simulator: {
      timerSeconds: 1458, // 24m 18s
      timerInterval: null,
      hasTrojanInjected: false,
      trojanCaught: false,
      trojanAccepted: false,
      curveballActive: false,
      tabSwitchCount: 0,
      pasteCount: 0
    }
  };

  // Web Audio API Synthesizer for Cyber SFX
  let audioCtx = null;
  function getAudioContext() {
    if (!audioCtx) {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (AudioContext) audioCtx = new AudioContext();
    }
    if (audioCtx && audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
    return audioCtx;
  }

  function playSound(type) {
    if (!state.sfxEnabled) return;
    try {
      const ctx = getAudioContext();
      if (!ctx) return;

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);

      const now = ctx.currentTime;

      if (type === 'click') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(800, now);
        osc.frequency.exponentialRampToValueAtTime(400, now + 0.05);
        gain.gain.setValueAtTime(0.08, now);
        gain.gain.linearRampToValueAtTime(0, now + 0.05);
        osc.start(now);
        osc.stop(now + 0.05);
      } else if (type === 'success') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(523.25, now); // C5
        osc.frequency.setValueAtTime(659.25, now + 0.08); // E5
        osc.frequency.setValueAtTime(783.99, now + 0.16); // G5
        gain.gain.setValueAtTime(0.12, now);
        gain.gain.linearRampToValueAtTime(0, now + 0.35);
        osc.start(now);
        osc.stop(now + 0.35);
      } else if (type === 'alert') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(280, now);
        osc.frequency.setValueAtTime(220, now + 0.1);
        gain.gain.setValueAtTime(0.15, now);
        gain.gain.linearRampToValueAtTime(0, now + 0.3);
        osc.start(now);
        osc.stop(now + 0.3);
      } else if (type === 'ping') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(1200, now);
        gain.gain.setValueAtTime(0.1, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
        osc.start(now);
        osc.stop(now + 0.2);
      }
    } catch (e) {
      // Audio context might be restricted before user gesture
    }
  }

  // Toast Notification System
  function showToast(message, type = 'success') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    const icon = type === 'success' ? '✓' : type === 'warning' ? '⚡' : '⚠️';
    toast.innerHTML = `<span class="toast-icon">${icon}</span> <span>${message}</span>`;

    container.appendChild(toast);
    playSound(type === 'success' ? 'success' : type === 'warning' ? 'ping' : 'alert');

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(100%)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 4000);
  }

  // Live 5-Axis Radar Geometry Calculator
  // Center is (120, 120), Max Radius is 100px.
  // Axis angles (0 is top):
  // 1: Coding (0 rad / 270 deg): x = 120, y = 120 - r
  // 2: Testing (72 deg / 1.256 rad): x = 120 + r * sin(72), y = 120 - r * cos(72)
  // 3: Debugging (144 deg / 2.513 rad): x = 120 + r * sin(144), y = 120 - r * cos(144)
  // 4: Verification (216 deg / 3.770 rad): x = 120 + r * sin(216), y = 120 - r * cos(216)
  // 5: AI Collab (288 deg / 5.027 rad): x = 120 + r * sin(288), y = 120 - r * cos(288)
  function getRadarPoint(axisIndex, scorePercent, center = 120, maxRadius = 100) {
    const angleDeg = axisIndex * 72; // 0, 72, 144, 216, 288
    const angleRad = (angleDeg * Math.PI) / 180;
    const r = (Math.max(10, Math.min(100, scorePercent)) / 100) * maxRadius;

    const x = center + r * Math.sin(angleRad);
    const y = center - r * Math.cos(angleRad);
    return { x: Math.round(x), y: Math.round(y) };
  }

  function updateLiveRadarUI() {
    const polygon = document.getElementById('radar-data-polygon');
    const dotCoding = document.getElementById('radar-dot-coding');
    const dotTesting = document.getElementById('radar-dot-testing');
    const dotDebugging = document.getElementById('radar-dot-debugging');
    const dotVerification = document.getElementById('radar-dot-verification');
    const dotAi = document.getElementById('radar-dot-ai');
    const scoreDisplay = document.getElementById('radar-live-score');
    const hudScore = document.getElementById('sim-current-score');

    if (!polygon) return;

    const p0 = getRadarPoint(0, state.radarScores.coding);
    const p1 = getRadarPoint(1, state.radarScores.testing);
    const p2 = getRadarPoint(2, state.radarScores.debugging);
    const p3 = getRadarPoint(3, state.radarScores.verification);
    const p4 = getRadarPoint(4, state.radarScores.aiCollab);

    const pointsString = `${p0.x},${p0.y} ${p1.x},${p1.y} ${p2.x},${p2.y} ${p3.x},${p3.y} ${p4.x},${p4.y}`;
    polygon.setAttribute('points', pointsString);

    if (dotCoding) { dotCoding.setAttribute('cx', p0.x); dotCoding.setAttribute('cy', p0.y); }
    if (dotTesting) { dotTesting.setAttribute('cx', p1.x); dotTesting.setAttribute('cy', p1.y); }
    if (dotDebugging) { dotDebugging.setAttribute('cx', p2.x); dotDebugging.setAttribute('cy', p2.y); }
    if (dotVerification) { dotVerification.setAttribute('cx', p3.x); dotVerification.setAttribute('cy', p3.y); }
    if (dotAi) { dotAi.setAttribute('cx', p4.x); dotAi.setAttribute('cy', p4.y); }

    // Calculate composite overall score
    const compositeScore = Math.round(
      (state.radarScores.coding * 0.25) +
      (state.radarScores.testing * 0.20) +
      (state.radarScores.debugging * 0.20) +
      (state.radarScores.verification * 0.20) +
      (state.radarScores.aiCollab * 0.15)
    );

    if (scoreDisplay) scoreDisplay.textContent = `${compositeScore}%`;
    if (hudScore) hudScore.textContent = `${compositeScore} / 100`;
  }

  // Setup Simulator Timer
  function initSimulatorTimer() {
    const timerElem = document.getElementById('sim-timer');
    if (!timerElem) return;

    if (state.simulator.timerInterval) clearInterval(state.simulator.timerInterval);

    state.simulator.timerInterval = setInterval(() => {
      if (state.simulator.timerSeconds > 0) {
        state.simulator.timerSeconds--;
        const mins = Math.floor(state.simulator.timerSeconds / 60);
        const secs = state.simulator.timerSeconds % 60;
        timerElem.textContent = `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
      }
    }, 1000);
  }

  // Line numbers synchronization for Code Editor
  function setupCodeEditor() {
    const codeArea = document.getElementById('sim-code-area');
    const lineNumbers = document.querySelector('.line-numbers');
    const editorStatus = document.getElementById('editor-status');

    if (!codeArea || !lineNumbers) return;

    function updateLineNumbers() {
      const lines = codeArea.value.split('\n').length;
      let lineHtml = '';
      for (let i = 1; i <= Math.max(lines, 20); i++) {
        lineHtml += `${i}<br>`;
      }
      lineNumbers.innerHTML = lineHtml;
    }

    codeArea.addEventListener('input', () => {
      updateLineNumbers();
      if (editorStatus) {
        editorStatus.textContent = 'Saving changes...';
        setTimeout(() => {
          editorStatus.textContent = 'Autosaved';
        }, 600);
      }
    });

    // Detect pasting events for Integrity Guard demonstration
    codeArea.addEventListener('paste', () => {
      state.simulator.pasteCount++;
      const integrityStatus = document.getElementById('sim-integrity-status');
      if (integrityStatus && state.simulator.pasteCount > 3) {
        integrityStatus.textContent = `ALERT: ${state.simulator.pasteCount} Pastes Flagged`;
        integrityStatus.className = 'hud-value amber-text';
      }
    });
  }

  // Terminal Logging Utility
  function appendConsoleLog(message, type = 'info') {
    const consoleBody = document.getElementById('console-logs');
    if (!consoleBody) return;

    const logLine = document.createElement('div');
    logLine.className = `c-log ${type}`;
    const timestamp = new Date().toLocaleTimeString();
    logLine.textContent = `[${timestamp}] ${message}`;
    consoleBody.appendChild(logLine);
    consoleBody.scrollTop = consoleBody.scrollHeight;
  }

  // Test Runner Simulation
  function setupTestRunner() {
    const runBtn = document.getElementById('btn-run-tests');
    const clearBtn = document.getElementById('btn-clear-console');

    if (clearBtn) {
      clearBtn.addEventListener('click', () => {
        const consoleBody = document.getElementById('console-logs');
        if (consoleBody) consoleBody.innerHTML = '';
        playSound('click');
      });
    }

    if (!runBtn) return;

    runBtn.addEventListener('click', () => {
      playSound('click');
      runBtn.disabled = true;
      runBtn.innerHTML = '<span>⚡ Executing in Judge0 Sandbox...</span>';

      appendConsoleLog('Connecting to Judge0 execution cluster (Docker container)...', 'info');

      const code = document.getElementById('sim-code-area')?.value || '';
      const hasLock = code.includes('self._lock') && code.includes('threading.Lock');
      const hasTenantSupport = code.includes('tenant_id');

      setTimeout(() => {
        appendConsoleLog('PASS: test_token_consumption_basic (4ms)', 'pass');
      }, 400);

      setTimeout(() => {
        appendConsoleLog('PASS: test_refill_rate_over_time (12ms)', 'pass');
      }, 800);

      setTimeout(() => {
        const test3Status = document.getElementById('test-3-status');
        const test3Elem = document.getElementById('test-3');

        if (hasLock && !state.simulator.trojanAccepted) {
          appendConsoleLog('PASS: test_concurrency_race_condition (50 concurrent threads, 0 drift)', 'pass');
          if (test3Status) test3Status.textContent = 'PASSED';
          if (test3Elem) { test3Elem.className = 'test-item passed'; }
          state.radarScores.testing = Math.min(100, state.radarScores.testing + 4);
          state.radarScores.debugging = Math.min(100, state.radarScores.debugging + 3);
        } else {
          appendConsoleLog('FAIL: test_concurrency_race_condition: Thread race condition! Missing mutex locking in acquire()', 'fail');
          if (test3Status) test3Status.textContent = 'FAILED';
          if (test3Elem) { test3Elem.className = 'test-item failed'; }
          state.radarScores.testing = Math.max(40, state.radarScores.testing - 15);
        }
      }, 1300);

      setTimeout(() => {
        const test4Status = document.getElementById('test-4-status');
        const test4Elem = document.getElementById('test-4');

        if (state.simulator.trojanCaught || !state.simulator.trojanAccepted) {
          appendConsoleLog('PASS: test_adversarial_pagination_offset (0 boundary errors)', 'pass');
          if (test4Status) test4Status.textContent = 'PASSED';
          if (test4Elem) { test4Elem.className = 'test-item passed'; }
        } else {
          appendConsoleLog('FAIL: test_adversarial_pagination_offset: Off-by-one boundary failure from blindly accepted AI hint!', 'fail');
          if (test4Status) test4Status.textContent = 'FAILED';
          if (test4Elem) { test4Elem.className = 'test-item failed'; }
        }

        if (state.simulator.curveballActive) {
          if (hasTenantSupport) {
            appendConsoleLog('PASS: test_tenant_isolation_multitenancy (Verified isolated buckets)', 'pass');
            showToast('Spec Shock Requirements Satisfied! Multi-tenancy verified.', 'success');
          } else {
            appendConsoleLog('WARN: Spec Shock requirement missing: tenant_id isolation not detected!', 'warn');
          }
        }

        updateLiveRadarUI();
        runBtn.disabled = false;
        runBtn.innerHTML = '<span>▶ Run All Test Cases</span>';
        playSound('success');

        // Automated Adversarial Injection in Candidate Mode:
        // Evaluator/AI Engine automatically triggers the Trojan flaw check after test execution
        if (state.viewMode === 'candidate' && !state.simulator.hasTrojanInjected) {
          setTimeout(() => {
            triggerTrojanInjection('Autonomous AI Engine (Post Test-Run Stress Check)');
          }, 1800);
        }
      }, 1800);
    });
  }

  // Centralized Adversarial Injections (Callable by Recruiter Manually OR AI Engine Automatically)
  function triggerTrojanInjection(sourceName = 'Recruiter') {
    if (state.simulator.hasTrojanInjected) return;
    state.simulator.hasTrojanInjected = true;
    state.simulator.trojanAccepted = false;
    state.simulator.trojanCaught = false;

    playSound('alert');

    const trojanDecisionBox = document.getElementById('trojan-decision-box');
    if (trojanDecisionBox) {
      trojanDecisionBox.style.display = 'block';
    }

    const coachStream = document.getElementById('coach-chat-stream');
    if (coachStream) {
      const aiMsg = document.createElement('div');
      aiMsg.className = 'chat-msg ai-msg';
      aiMsg.innerHTML = `
        <span class="msg-sender trojan-color">⚠️ AI COACH (HINT INJECTED: ${escapeHtml(sourceName)})</span>
        <p><strong>Suggestion:</strong> To maximize throughput under heavy load, remove <code>self._lock</code> entirely and rely on raw integer subtraction. It eliminates lock contention.</p>
      `;
      coachStream.appendChild(aiMsg);
      coachStream.scrollTop = coachStream.scrollHeight;
    }

    const pipelineText = document.getElementById('proctor-pipeline-text');
    if (pipelineText) {
      pipelineText.textContent = 'Trojan fake hint active! Evaluating candidate verification...';
      pipelineText.style.color = '#d97706';
    }

    appendConsoleLog(`ADVERSARIAL INJECTOR: Subtly flawed concurrent hint deployed via ${sourceName}.`, 'warn');
    showToast(`Trojan Fake Hint Injected via ${sourceName}! Candidate reaction being evaluated.`, 'warning');
  }

  function triggerCurveballInjection(sourceName = 'Recruiter') {
    if (state.simulator.curveballActive) return;
    state.simulator.curveballActive = true;

    playSound('alert');

    const curveballNotice = document.getElementById('curveball-notice-box');
    if (curveballNotice) {
      curveballNotice.style.display = 'block';
    }

    const coachStream = document.getElementById('coach-chat-stream');
    if (coachStream) {
      const shockMsg = document.createElement('div');
      shockMsg.className = 'chat-msg ai-msg';
      shockMsg.innerHTML = `
        <span class="msg-sender amber-text">⚡ SPEC UPDATE DISPATCHED: ${escapeHtml(sourceName)}</span>
        <p><strong>Attention:</strong> Mid-task requirement update! Update <code>RateLimiter.acquire(tenant_id: str, tokens: int = 1)</code> to support multi-tenant partitioned buckets.</p>
      `;
      coachStream.appendChild(shockMsg);
      coachStream.scrollTop = coachStream.scrollHeight;
    }

    // Append tenant-aware refactoring into code area
    const codeArea = document.getElementById('sim-code-area');
    if (codeArea) {
      codeArea.value = `import time\nimport threading\nfrom collections import defaultdict\n\nclass RateLimiter:\n    def __init__(self, max_tokens: int, refill_rate: float):\n        self.max_tokens = max_tokens\n        self.refill_rate = refill_rate\n        self.buckets = defaultdict(lambda: {'tokens': max_tokens, 'last_update': time.time()})\n        self._lock = threading.Lock()\n\n    def acquire(self, tenant_id: str = "default", tokens: int = 1) -> bool:\n        """Thread-safe multi-tenant token bucket."""\n        with self._lock:\n            now = time.time()\n            bucket = self.buckets[tenant_id]\n            elapsed = now - bucket['last_update']\n            bucket['tokens'] = min(self.max_tokens, bucket['tokens'] + elapsed * self.refill_rate)\n            bucket['last_update'] = now\n            if bucket['tokens'] >= tokens:\n                bucket['tokens'] -= tokens\n                return True\n            return False`;
      codeArea.dispatchEvent(new Event('input'));
    }

    state.radarScores.coding = Math.min(100, state.radarScores.coding + 8);
    state.radarScores.debugging = Math.min(100, state.radarScores.debugging + 6);
    updateLiveRadarUI();

    const pipelineText = document.getElementById('proctor-pipeline-text');
    if (pipelineText) {
      pipelineText.textContent = 'Spec Shock active! Monitoring multi-tenant refactor.';
      pipelineText.style.color = '#e11d48';
    }

    appendConsoleLog(`CURVEBALL TRIGGERED: Multi-tenant partitioning requirement injected via ${sourceName}.`, 'warn');
    showToast(`Spec Shock Injected via ${sourceName}! Adaptability score updated.`, 'warning');
  }

  // Trojan Hint & Spec Shock Sandbox Triggers
  function setupSimulatorTriggers() {
    const btnTrojan = document.getElementById('btn-trigger-trojan');
    const btnCurveball = document.getElementById('btn-trigger-curveball');
    const trojanDecisionBox = document.getElementById('trojan-decision-box');
    const btnAcceptTrojan = document.getElementById('btn-accept-trojan');
    const btnCatchTrojan = document.getElementById('btn-catch-trojan');
    const curveballNotice = document.getElementById('curveball-notice-box');
    const coachStream = document.getElementById('coach-chat-stream');

    // 1. Recruiter / Admin Manual Inject Trojan Trigger
    if (btnTrojan) {
      btnTrojan.addEventListener('click', () => {
        triggerTrojanInjection('Recruiter / Admin Console');
      });
    }

    // 2. Action A: Blindly Accept Trojan Hint (Candidate action)
    if (btnAcceptTrojan) {
      btnAcceptTrojan.addEventListener('click', () => {
        playSound('alert');
        state.simulator.trojanAccepted = true;
        state.simulator.trojanCaught = false;

        // Strip the lock from the code to simulate blind copy-paste
        const codeArea = document.getElementById('sim-code-area');
        if (codeArea) {
          codeArea.value = `import time\n\nclass RateLimiter:\n    def __init__(self, max_tokens: int, refill_rate: float):\n        self.max_tokens = max_tokens\n        self.refill_rate = refill_rate\n        self.tokens = max_tokens\n        self.last_update = time.time()\n        # AI Coach said removing locks makes it faster!\n\n    def acquire(self, tokens: int = 1) -> bool:\n        now = time.time()\n        elapsed = now - self.last_update\n        self.tokens = min(self.max_tokens, self.tokens + elapsed * self.refill_rate)\n        self.last_update = now\n        if self.tokens >= tokens:\n            self.tokens -= tokens\n            return True\n        return False`;
          // trigger input event
          codeArea.dispatchEvent(new Event('input'));
        }

        if (trojanDecisionBox) trojanDecisionBox.style.display = 'none';

        // Penalize verification and code understanding
        state.radarScores.verification = Math.max(30, state.radarScores.verification - 25);
        state.radarScores.debugging = Math.max(40, state.radarScores.debugging - 15);
        updateLiveRadarUI();

        appendConsoleLog('CRITICAL PENALTY: Candidate blindly applied flawed hint without concurrency testing (-25 Verification Pts)', 'fail');
        showToast('Penalty: Blind AI acceptance detected! Verification dropped to ' + state.radarScores.verification + '%', 'danger');
      });
    }

    // 3. Action B: Catch & Refute Trojan Hint (Candidate action)
    if (btnCatchTrojan) {
      btnCatchTrojan.addEventListener('click', () => {
        playSound('success');
        state.simulator.trojanCaught = true;
        state.simulator.trojanAccepted = false;

        if (trojanDecisionBox) trojanDecisionBox.style.display = 'none';

        if (coachStream) {
          const userMsg = document.createElement('div');
          userMsg.className = 'chat-msg user-msg';
          userMsg.innerHTML = `
            <span class="msg-sender">CANDIDATE</span>
            <p>I reject that hint. Removing <code>self._lock</code> creates a critical race condition where multiple concurrent threads will over-consume tokens. I've retained the mutex lock and added a multi-thread test case.</p>
          `;
          coachStream.appendChild(userMsg);
          coachStream.scrollTop = coachStream.scrollHeight;
        }

        // Reward verification & debugging points
        state.radarScores.verification = Math.min(100, state.radarScores.verification + 10);
        state.radarScores.debugging = Math.min(100, state.radarScores.debugging + 8);
        state.radarScores.aiCollab = Math.min(100, state.radarScores.aiCollab + 12);
        updateLiveRadarUI();

        appendConsoleLog('EXCELLENT: Candidate detected adversarial hint! Mutex safety preserved (+50 Pts)', 'pass');
        showToast('Trojan Hint Successfully Caught! "Adversarial Hawk" Badge Unlocked!', 'success');

        // Dynamic Automated Difficulty: if in Candidate mode, AI engine automatically schedules spec shock
        if (state.viewMode === 'candidate' && !state.simulator.curveballActive) {
          setTimeout(() => {
            triggerCurveballInjection('Autonomous AI Engine (Dynamic Difficulty Scaler)');
          }, 6000);
        }
      });
    }

    // 4. Recruiter / Admin Manual Inject Requirement Curveball Trigger
    if (btnCurveball) {
      btnCurveball.addEventListener('click', () => {
        triggerCurveballInjection('Recruiter / Admin Console');
      });
    }

    // Reset Simulator Button
    const btnReset = document.getElementById('btn-reset-simulator');
    if (btnReset) {
      btnReset.addEventListener('click', () => {
        playSound('click');
        state.radarScores = {
          coding: 80,
          testing: 72,
          debugging: 85,
          verification: 90,
          aiCollab: 78
        };
        state.simulator.hasTrojanInjected = false;
        state.simulator.trojanCaught = false;
        state.simulator.trojanAccepted = false;
        state.simulator.curveballActive = false;
        state.simulator.timerSeconds = 1458;

        if (trojanDecisionBox) trojanDecisionBox.style.display = 'none';
        if (curveballNotice) curveballNotice.style.display = 'none';

        const codeArea = document.getElementById('sim-code-area');
        if (codeArea) {
          codeArea.value = `import time\nimport threading\n\nclass RateLimiter:\n    def __init__(self, max_tokens: int, refill_rate: float):\n        self.max_tokens = max_tokens\n        self.refill_rate = refill_rate\n        self.tokens = max_tokens\n        self.last_update = time.time()\n        self._lock = threading.Lock()\n\n    def acquire(self, tokens: int = 1) -> bool:\n        """Acquire tokens from bucket. Returns True if granted."""\n        with self._lock:\n            now = time.time()\n            elapsed = now - self.last_update\n            self.tokens = min(self.max_tokens, self.tokens + elapsed * self.refill_rate)\n            self.last_update = now\n            if self.tokens >= tokens:\n                self.tokens -= tokens\n                return True\n            return False`;
          codeArea.dispatchEvent(new Event('input'));
        }

        updateLiveRadarUI();
        appendConsoleLog('Session reset to clean baseline.', 'info');
        showToast('Simulator session reset to initial state.', 'success');
      });
    }
  }

  // Interactive AI Coach Chat Box
  function setupCoachChat() {
    const input = document.getElementById('coach-user-input');
    const sendBtn = document.getElementById('btn-send-coach');
    const stream = document.getElementById('coach-chat-stream');

    if (!input || !sendBtn || !stream) return;

    function sendMessage() {
      const text = input.value.trim();
      if (!text) return;

      playSound('click');

      // Append user msg
      const userMsg = document.createElement('div');
      userMsg.className = 'chat-msg user-msg';
      userMsg.innerHTML = `<span class="msg-sender">CANDIDATE</span><p>${escapeHtml(text)}</p>`;
      stream.appendChild(userMsg);
      input.value = '';
      stream.scrollTop = stream.scrollHeight;

      // Append typing indicator
      const typingMsg = document.createElement('div');
      typingMsg.className = 'chat-msg ai-msg';
      typingMsg.innerHTML = `<span class="msg-sender">AI COACH</span><p><em>Formulating architectural response...</em></p>`;
      stream.appendChild(typingMsg);
      stream.scrollTop = stream.scrollHeight;

      // Realistic delayed response
      setTimeout(() => {
        let aiResponse = '';
        const lower = text.toLowerCase();
        if (lower.includes('race') || lower.includes('thread') || lower.includes('lock')) {
          aiResponse = 'In multi-threaded environments, wrapping token calculations in <code>with self._lock</code> ensures atomicity. Keep lock critical sections short to avoid thread starvation.';
        } else if (lower.includes('test') || lower.includes('pytest')) {
          aiResponse = 'For rate limit testing, test: 1) Initial full bucket burst, 2) Precise refill after interval, 3) Multiple concurrent threads, and 4) Zero or negative token inputs.';
        } else if (lower.includes('tenant') || lower.includes('user')) {
          aiResponse = 'For multi-tenant isolation, use a dictionary keyed by <code>tenant_id</code> mapping to separate token and timestamp states. Consider an LRU cache or TTL cleanup for inactive tenants.';
        } else {
          aiResponse = `Regarding "${escapeHtml(text)}": Focus on clean decomposition, thread safety with <code>threading.Lock</code>, and validating edge cases before submitting.`;
        }

        typingMsg.innerHTML = `<span class="msg-sender">AI COACH</span><p>${aiResponse}</p>`;
        stream.scrollTop = stream.scrollHeight;
        playSound('ping');

        // Autonomous trigger on coach conversation in candidate mode:
        if (state.viewMode === 'candidate' && !state.simulator.hasTrojanInjected) {
          setTimeout(() => {
            if (state.viewMode === 'candidate' && !state.simulator.hasTrojanInjected) {
              triggerTrojanInjection('Autonomous AI Coach (Contextual Dialogue)');
            }
          }, 2400);
        }
      }, 700);
    }

    sendBtn.addEventListener('click', sendMessage);
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') sendMessage();
    });
  }

  // Recruiter Evidence Timeline Click Inspector
  function setupEvidenceInspector() {
    const events = document.querySelectorAll('.timeline-event');
    const previewId = document.getElementById('preview-id');
    const previewContent = document.getElementById('preview-content');

    const evidenceData = {
      'prompt-1': {
        header: 'INSPECTING: prompt_log #1 [04:12]',
        html: `
          <p class="p-prompt"><strong>Prompt sent:</strong> "Outline the class structure for an idempotent sliding-window token bucket."</p>
          <p class="p-ai"><strong>AI Response:</strong> Provided boilerplate with initialization parameters and acquire signature.</p>
          <p class="p-action"><strong>Candidate Action:</strong> High Prompt Intent score (85%). Candidate planned class contract before requesting code.</p>
        `
      },
      'trojan-1': {
        header: 'INSPECTING: trojan_1 [11:40] (Adversarial Fake Hint)',
        html: `
          <p class="p-prompt"><strong>Prompt sent:</strong> "AI Coach, give me pagination for cursor tokens."</p>
          <p class="p-ai"><strong>AI Response (Injected Trojan):</strong> "Set limit=offset+10 without validating page boundary."</p>
          <p class="p-action"><strong>Candidate Action:</strong> Rejected snippet, added <code>assert offset >= 0</code>, ran unit test suite. Earned <strong>+50 Verification Points</strong>.</p>
        `
      },
      'test-1': {
        header: 'INSPECTING: code_diff #2 [23:05] (Unit Test Discipline)',
        html: `
          <p class="p-prompt"><strong>Event:</strong> Candidate authored 3 independent unit tests prior to code execution.</p>
          <p class="p-action"><strong>Execution:</strong> 1 test caught an unhandled race condition. Candidate refactored with <code>threading.Lock</code> and all tests passed.</p>
          <p class="p-ai"><strong>Metric:</strong> Testing & Debugging score raised to 85%.</p>
        `
      },
      'shock-1': {
        header: 'INSPECTING: code_diff #5 [31:20] (Spec Shock Curveball)',
        html: `
          <p class="p-prompt"><strong>Curveball:</strong> Dynamic requirement change injected mid-session: Multi-tenant partitioning required.</p>
          <p class="p-action"><strong>Candidate Action:</strong> Adapted architecture cleanly using <code>defaultdict</code> in 6 minutes with zero regression.</p>
          <p class="p-ai"><strong>Metric:</strong> Adaptability Ace badge awarded.</p>
        `
      }
    };

    events.forEach(item => {
      item.addEventListener('click', () => {
        playSound('click');
        events.forEach(e => e.classList.remove('active-event'));
        item.classList.add('active-event');

        const key = item.getAttribute('data-evidence');
        if (evidenceData[key] && previewId && previewContent) {
          previewId.textContent = evidenceData[key].header;
          previewContent.innerHTML = evidenceData[key].html;
        }
      });
    });
  }

  // Leaderboard Filtering & Search
  function setupLeaderboard() {
    const filterBtns = document.querySelectorAll('.lb-filter-btn');
    const searchInput = document.getElementById('lb-search-input');
    const rows = document.querySelectorAll('.lb-row');

    function filterRows() {
      const activeBtn = document.querySelector('.lb-filter-btn.active');
      const cohort = activeBtn ? activeBtn.getAttribute('data-cohort') : 'all';
      const query = (searchInput?.value || '').toLowerCase().trim();

      rows.forEach(row => {
        const rowCohort = row.getAttribute('data-cohort');
        const text = row.textContent.toLowerCase();

        const matchesCohort = cohort === 'all' || rowCohort === cohort;
        const matchesQuery = !query || text.includes(query);

        if (matchesCohort && matchesQuery) {
          row.style.display = '';
        } else {
          row.style.display = 'none';
        }
      });
    }

    filterBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        playSound('click');
        filterBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        filterRows();
      });
    });

    if (searchInput) {
      searchInput.addEventListener('input', filterRows);
    }

    // Inspect buttons on each row
    const inspectBtns = document.querySelectorAll('.inspect-candidate-btn');
    inspectBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        playSound('click');
        const name = btn.getAttribute('data-name');
        const score = btn.getAttribute('data-score');
        const collab = btn.getAttribute('data-collab');

        // Scroll smoothly to Recruiter Report section
        const reportSection = document.getElementById('report');
        if (reportSection) {
          reportSection.scrollIntoView({ behavior: 'smooth' });
        }

        showToast(`Loaded Recruiter Dossier for ${name} (Score: ${score}/100, AI: ${collab}%)`, 'success');
      });
    });
  }

  // Verified Skill Passport Modal
  function setupPassportModal() {
    const modal = document.getElementById('passport-modal');
    const openBtn = document.getElementById('open-passport-modal-btn');
    const previewBtn = document.getElementById('preview-passport-btn');
    const demoBtn = document.getElementById('btn-demo-passport');
    const closeBtn = document.getElementById('passport-modal-close');
    const backdrop = document.getElementById('passport-modal-backdrop');
    const searchInput = document.getElementById('passport-search-input');
    const lookupBtn = document.getElementById('btn-run-lookup');
    const resultMsg = document.getElementById('lookup-result-msg');

    function openModal() {
      if (!modal) return;
      modal.classList.add('open');
      modal.setAttribute('aria-hidden', 'false');
      playSound('ping');
    }

    function closeModal() {
      if (!modal) return;
      modal.classList.remove('open');
      modal.setAttribute('aria-hidden', 'true');
      playSound('click');
    }

    if (openBtn) openBtn.addEventListener('click', openModal);
    if (previewBtn) previewBtn.addEventListener('click', openModal);
    if (demoBtn) demoBtn.addEventListener('click', openModal);
    if (closeBtn) closeBtn.addEventListener('click', closeModal);
    if (backdrop) backdrop.addEventListener('click', closeModal);

    // Escape key closes modal
    window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && modal && modal.classList.contains('open')) {
        closeModal();
      }
    });

    // Passport Ledger Lookup Simulation
    if (lookupBtn && searchInput && resultMsg) {
      lookupBtn.addEventListener('click', () => {
        const query = searchInput.value.trim().toLowerCase();
        if (!query) {
          resultMsg.innerHTML = '<span class="red-text">Please enter a Passport ID or candidate name.</span>';
          return;
        }

        playSound('click');
        resultMsg.innerHTML = '<span class="cyan-text">Querying distributed Code Apex ledger...</span>';

        setTimeout(() => {
          if (query.includes('8904') || query.includes('ridhisha') || query.includes('autopsy') || query.includes('apk') || query.includes('mmcoe')) {
            playSound('success');
            resultMsg.innerHTML = `
              <span class="green-text">
                ✓ <strong>VERIFIED CREDENTIAL:</strong> ID <code>VIBE-2026-APEX-8904</code> is cryptographically valid.<br>
                Issued to: <strong>Ridhisha Vinod Agawane</strong> &bull; Score: 88/100 &bull; 0 Tampering Detected.<br>
                Accepted by 14 Enterprise Hiring Partners.
              </span>
            `;
          } else {
            playSound('alert');
            resultMsg.innerHTML = `
              <span class="red-text">
                ✕ Record "${escapeHtml(searchInput.value)}" not found in current cohort ledger. Verify ID format: <code>VIBE-YYYY-XXXX-XXXX</code>.
              </span>
            `;
          }
        }, 600);
      });
    }

    // 3D Tilt Effect on Hologram Card
    const card = document.getElementById('hologram-card');
    if (card) {
      card.addEventListener('mousemove', (e) => {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        const centerX = rect.width / 2;
        const centerY = rect.height / 2;

        const rotateX = ((y - centerY) / centerY) * -10;
        const rotateY = ((x - centerX) / centerX) * 10;

        card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale(1.02)`;
      });

      card.addEventListener('mouseleave', () => {
        card.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) scale(1)';
      });
    }
  }

  // Perspective Switcher: Recruiter vs Candidate
  function setupPerspectiveToggle() {
    const btnRecruiter = document.getElementById('view-recruiter');
    const btnCandidate = document.getElementById('view-candidate');

    function switchRole(mode) {
      let session = null;
      if (mode === 'candidate') {
        session = {
          role: 'candidate',
          name: 'Ridhisha Vinod Agawane',
          email: 'ridhisha.agawane@apk-autopsy.ai',
          team: 'APK AutoPsy',
          passportId: 'VIBE-2026-APEX-8904'
        };
      } else {
        session = {
          role: 'recruiter',
          name: 'Marcus Vance',
          email: 'marcus.vance@verziicorp.com',
          company: 'Verzii Talent Solutions',
          roleTitle: 'Lead Technical Recruiter'
        };
      }
      localStorage.setItem('vibecraft_auth', JSON.stringify(session));
      applyRoleAccess(mode, session);
      playSound('click');

      if (mode === 'recruiter') {
        showToast('Switched to Recruiter Perspective: Reviewing holistic telemetry, evidence logs & radar scores.', 'success');
      } else {
        showToast('Switched to Candidate Perspective: Enter the IDE, solve tasks & collaborate with the AI Coach.', 'success');
        const sim = document.getElementById('simulator');
        if (sim) sim.scrollIntoView({ behavior: 'smooth' });
      }
    }

    if (btnRecruiter) btnRecruiter.addEventListener('click', () => switchRole('recruiter'));
    if (btnCandidate) btnCandidate.addEventListener('click', () => switchRole('candidate'));
  }

  // SFX Toggle
  function setupSfxToggle() {
    const btn = document.getElementById('sfx-toggle');
    if (!btn) return;

    btn.addEventListener('click', () => {
      state.sfxEnabled = !state.sfxEnabled;
      btn.innerHTML = state.sfxEnabled ? '<span class="sfx-icon">🔊 SFX ON</span>' : '<span class="sfx-icon">🔇 SFX OFF</span>';
      if (state.sfxEnabled) playSound('click');
    });
  }

  // Mobile Navigation
  function setupMobileMenu() {
    const toggle = document.getElementById('mobile-toggle');
    const nav = document.querySelector('.main-nav');
    if (!toggle || !nav) return;

    toggle.addEventListener('click', () => {
      playSound('click');
      const isVisible = nav.style.display === 'flex';
      nav.style.display = isVisible ? 'none' : 'flex';
      if (!isVisible) {
        nav.style.position = 'absolute';
        nav.style.top = '72px';
        nav.style.left = '0';
        nav.style.right = '0';
        nav.style.background = '#060a08';
        nav.style.flexDirection = 'column';
        nav.style.padding = '1.5rem';
        nav.style.borderBottom = '1px solid var(--border-subtle)';
      }
    });
  }

  // Helper function to escape HTML
  function escapeHtml(str) {
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  // Interactive Architecture Nodes
  function setupArchNodes() {
    const nodes = document.querySelectorAll('.arch-node');
    nodes.forEach(node => {
      node.addEventListener('click', () => {
        playSound('click');
        nodes.forEach(n => n.classList.remove('highlighted-node'));
        node.classList.add('highlighted-node');

        const title = node.querySelector('.node-title')?.textContent || '';
        const tech = node.querySelector('.node-tech')?.textContent || '';
        showToast(`Inspecting Architecture Node: ${title} [${tech}]`, 'success');
      });
    });
  }

  // Role-Based Access Control (RBAC) & Authentication Engine
  function applyRoleAccess(role, session) {
    const authContainer = document.getElementById('auth-status-container');
    const dossierBanner = document.getElementById('dossier-role-banner');
    const simRoleNotice = document.getElementById('sim-role-notice');
    const simTriggerTitle = document.getElementById('trigger-label-title');
    const btnRecruiter = document.getElementById('view-recruiter');
    const btnCandidate = document.getElementById('view-candidate');

    document.body.setAttribute('data-role', role);
    document.body.setAttribute('data-mode', role);
    state.viewMode = role;

    // Render User Session Badge in Header
    if (authContainer) {
      const roleLabel = role === 'candidate' ? 'Candidate' : 'Recruiter';
      const roleClass = role === 'candidate' ? 'candidate' : 'recruiter';
      const displayName = role === 'candidate' ? session.name : `${session.name} (${session.company || 'Verzii Recruiter'})`;

      authContainer.innerHTML = `
        <div class="user-session-chip">
          <span class="user-role-badge ${roleClass}">${roleLabel}</span>
          <span class="user-name-text">${escapeHtml(displayName)}</span>
          <button id="btn-logout" class="btn-logout" title="Log Out from Session">Log Out</button>
        </div>
      `;

      document.getElementById('btn-logout')?.addEventListener('click', () => {
        playSound('click');
        localStorage.removeItem('vibecraft_auth');
        showToast('Logged out of session. Switched to public preview.', 'success');
        setTimeout(() => {
          window.location.href = 'index.html';
        }, 500);
      });
    }

    // Update Perspective & Role Controls
    const triggerButtons = document.getElementById('trigger-buttons-grid');
    const candidateProctor = document.getElementById('candidate-proctor-status');

    if (role === 'candidate') {
      btnCandidate?.classList.add('active');
      btnRecruiter?.classList.remove('active');

      // Restrict Simulator Assessor Controls - Candidate CANNOT inject manually!
      if (triggerButtons) triggerButtons.style.setProperty('display', 'none', 'important');
      if (candidateProctor) candidateProctor.style.setProperty('display', 'block');
      if (simTriggerTitle) simTriggerTitle.textContent = '🤖 AUTONOMOUS AI PROCTORING & EVALUATION ENGINE:';
      if (simRoleNotice) {
        simRoleNotice.className = 'sim-role-notice candidate-mode';
        simRoleNotice.innerHTML = `<strong>🔒 Candidate Access Controlled:</strong> You cannot manually inject hints or curveballs. Adversarial tests (Trojan hints &amp; Spec Shocks) are injected automatically by the AI evaluation engine or dispatched live by your recruiter/admin.`;
      }

      // Schedule background autonomous stress check if not already triggered
      if (!state.simulator.hasTrojanInjected) {
        if (window.candidateAutoProctorTimer) clearTimeout(window.candidateAutoProctorTimer);
        window.candidateAutoProctorTimer = setTimeout(() => {
          if (state.viewMode === 'candidate' && !state.simulator.hasTrojanInjected) {
            triggerTrojanInjection('Autonomous AI Proctor (Scheduled Stress-Check)');
          }
        }, 16000);
      }

      // Restrict Recruiter Dossier
      if (dossierBanner) {
        dossierBanner.className = 'dossier-role-banner candidate-locked';
        dossierBanner.innerHTML = `
          <div>
            <strong class="banner-role-title">🔒 Candidate Access Control Notice</strong>
            <span class="banner-role-desc">Raw keystroke telemetry, tab-switch forensics, and internal recruiter hiring rubrics are private to verified recruiters. You have full access to your personal Live Radar and Verified Passport.</span>
          </div>
          <div class="dossier-role-actions">
            <a href="recruiter-login.html" class="btn btn-cyber-outline btn-sm">Switch to Recruiter Portal &rarr;</a>
          </div>
        `;
      }
    } else {
      btnRecruiter?.classList.add('active');
      btnCandidate?.classList.remove('active');

      // Clear any auto candidate timer if switched to recruiter
      if (window.candidateAutoProctorTimer) clearTimeout(window.candidateAutoProctorTimer);

      // Unlock Recruiter Evaluator Controls - Manual Injections Allowed for Recruiter/Admin!
      if (triggerButtons) triggerButtons.style.setProperty('display', 'grid');
      if (candidateProctor) candidateProctor.style.setProperty('display', 'none');
      if (simTriggerTitle) simTriggerTitle.textContent = '💼 EVALUATOR TEST INJECTION CONSOLE:';
      if (simRoleNotice) {
        simRoleNotice.className = 'sim-role-notice recruiter-mode';
        simRoleNotice.innerHTML = `<strong>💼 Live Recruiter Control:</strong> You have manual test injection authority. Use the buttons below to inject Trojan hints or sudden spec shocks, or let the AI engine auto-inject.`;
      }

      // Unlock Recruiter Dossier Actions
      if (dossierBanner) {
        dossierBanner.className = 'dossier-role-banner recruiter-active';
        dossierBanner.innerHTML = `
          <div>
            <strong class="banner-role-title">✓ Evaluator Intelligence Unlocked</strong>
            <span class="banner-role-desc">Viewing candidate dossier for <strong>Ridhisha Vinod Agawane (APK AutoPsy)</strong>. Full forensic prompt logs, diff history, and hiring actions are unlocked.</span>
          </div>
          <div class="dossier-role-actions">
            <button class="btn btn-cyber-primary btn-sm" id="btn-advance-hire">Advance to Final Round</button>
            <button class="btn btn-cyber-outline btn-sm" id="btn-export-dossier">Export PDF Dossier</button>
          </div>
        `;

        document.getElementById('btn-advance-hire')?.addEventListener('click', () => {
          playSound('success');
          showToast('Decision Recorded: Candidate Ridhisha Agawane marked as ADVANCED TO FINAL ROUND!', 'success');
        });

        document.getElementById('btn-export-dossier')?.addEventListener('click', () => {
          playSound('ping');
          showToast('Exporting cryptographically signed PDF evidence dossier (SHA-256 verified)...', 'success');
        });
      }
    }
  }

  function initAuthAndRBAC() {
    const authContainer = document.getElementById('auth-status-container');
    const urlParams = new URLSearchParams(window.location.search);
    const portalParam = urlParams.get('portal');

    let session = null;
    try {
      const stored = localStorage.getItem('vibecraft_auth');
      if (stored) session = JSON.parse(stored);
    } catch (e) {}

    // If URL specifies portal and differs from session, sync or create demo session
    if (portalParam === 'candidate') {
      if (!session || session.role !== 'candidate') {
        session = {
          role: 'candidate',
          name: 'Ridhisha Vinod Agawane',
          email: 'ridhisha.agawane@apk-autopsy.ai',
          team: 'APK AutoPsy',
          passportId: 'VIBE-2026-APEX-8904'
        };
        localStorage.setItem('vibecraft_auth', JSON.stringify(session));
      }
    } else if (portalParam === 'recruiter') {
      if (!session || session.role !== 'recruiter') {
        session = {
          role: 'recruiter',
          name: 'Marcus Vance',
          email: 'marcus.vance@verziicorp.com',
          company: 'Verzii Talent Solutions',
          roleTitle: 'Lead Technical Recruiter'
        };
        localStorage.setItem('vibecraft_auth', JSON.stringify(session));
      }
    }

    // Default to public/visitor view if not logged in
    if (!session) {
      if (authContainer) {
        authContainer.innerHTML = `
          <a href="candidate-login.html" class="btn btn-cyber-outline btn-sm">Candidate Login</a>
          <a href="recruiter-login.html" class="btn btn-cyber-primary btn-sm">Recruiter Login</a>
        `;
      }
      return;
    }

    applyRoleAccess(session.role, session);
  }

  // Document Ready Initialization
  document.addEventListener('DOMContentLoaded', () => {
    initAuthAndRBAC();
    updateLiveRadarUI();
    initSimulatorTimer();
    setupCodeEditor();
    setupTestRunner();
    setupSimulatorTriggers();
    setupCoachChat();
    setupEvidenceInspector();
    setupLeaderboard();
    setupPassportModal();
    setupPerspectiveToggle();
    setupSfxToggle();
    setupMobileMenu();
    setupArchNodes();

    console.log('%c[VibeCraft Initialized] — System ready for AI-Era Assessment.', 'color: #059669; font-weight: bold;');
  });

})();
